import React from 'react';

class Page extends React.Component{

render(){
    console.log(window.location.href);
return(
    
    
    <p>the account has been added</p>
    );
    };
}

export default Page;